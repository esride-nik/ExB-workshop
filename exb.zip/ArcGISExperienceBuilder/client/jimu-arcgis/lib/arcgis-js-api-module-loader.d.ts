export declare function loadArcGISJSAPIModules(modules: string[]): Promise<any[]>;
