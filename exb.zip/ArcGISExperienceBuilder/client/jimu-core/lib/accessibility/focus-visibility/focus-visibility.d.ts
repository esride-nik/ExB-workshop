import * as React from 'react';
export declare const INTERACTIVE_CLASS = "jimu-interactive-node";
export declare function isKeyboardMode(): boolean;
export declare function FocusVisibility(props: any): React.JSX.Element;
