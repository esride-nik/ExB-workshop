import { jsx } from '@emotion/react';
import { type DialogProps } from '../types';
declare function FixedDialog({ dialogJson, ...props }: DialogProps): jsx.JSX.Element;
export default FixedDialog;
