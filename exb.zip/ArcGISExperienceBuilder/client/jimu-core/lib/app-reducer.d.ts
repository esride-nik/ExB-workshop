import { type ActionTypes } from './app-actions';
import { type IMState } from './types/state';
export default function rootReducer(state: IMState, action: ActionTypes): IMState;
