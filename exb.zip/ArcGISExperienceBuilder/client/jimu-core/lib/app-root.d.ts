import * as React from 'react';
export default function AppRoot(): React.JSX.Element;
