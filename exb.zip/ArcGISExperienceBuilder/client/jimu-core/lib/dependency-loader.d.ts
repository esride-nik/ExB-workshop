export declare function loadDependency(dependency: string): Promise<void>;
export declare function loadDependencies(dependencies: string[]): Promise<void>;
