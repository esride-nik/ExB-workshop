declare const isIgnoreElement: (element: any) => boolean;
export default isIgnoreElement;
