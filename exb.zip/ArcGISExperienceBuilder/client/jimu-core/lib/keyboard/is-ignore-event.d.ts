declare const isIgnoreEvent: (event: any) => boolean;
export default isIgnoreEvent;
