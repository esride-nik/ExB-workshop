import * as React from 'react';
export declare function LoadingHandler(props: any): React.JSX.Element;
