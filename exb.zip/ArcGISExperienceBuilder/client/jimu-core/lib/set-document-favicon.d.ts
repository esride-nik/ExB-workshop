import { type IMThemeVariables } from './types/theme';
interface SetDocumentFaviconProps {
    themeVariables: IMThemeVariables;
}
export declare function SetDocumentFavicon(props: SetDocumentFaviconProps): any;
export {};
