export declare function triggerEvent(event: KeyboardEvent): void;
