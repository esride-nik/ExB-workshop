import JsonEditorSetting from './lib/json-editor-setting';
export default JsonEditorSetting;
