import { type IUpdateItemOptions, type IUpdateItemResponse } from '@esri/arcgis-rest-portal';
export declare function updateItem(requestOptions: IUpdateItemOptions): Promise<IUpdateItemResponse>;
