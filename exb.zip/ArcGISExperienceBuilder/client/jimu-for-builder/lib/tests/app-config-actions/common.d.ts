import { type AppConfig, type IMAppConfig } from 'jimu-core';
export declare function buildAppStructure(appConfig: any): any;
export declare function initLayoutServiceProvider(): void;
export declare function checkAppStructure(appConfig: AppConfig | IMAppConfig): void;
