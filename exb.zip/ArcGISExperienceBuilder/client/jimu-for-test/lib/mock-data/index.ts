import * as featureServiceMockData from './feature-service'
import * as mapServiceMockData from './map-service'
import * as mapItemMockData from './map-item'
import * as featureCollectionItemMockData from './feature-collection-item'

export { featureServiceMockData, mapServiceMockData, mapItemMockData, featureCollectionItemMockData }
