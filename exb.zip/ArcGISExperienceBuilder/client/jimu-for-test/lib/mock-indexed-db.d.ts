export declare function mockIndexedDB(): void;
