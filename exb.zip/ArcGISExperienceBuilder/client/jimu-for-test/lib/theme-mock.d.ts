declare let defaultTheme: import("jimu-core").IMThemeVariables;
export default defaultTheme;
